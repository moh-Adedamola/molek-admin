import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { studentsAPI, classLevelsAPI } from "../api/endpoints";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";
import { Modal } from "../components/ui/Modal";

export function StudentsList() {
    const navigate = useNavigate();
    const [students, setStudents] = useState([]);
    const [classLevels, setClassLevels] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [classFilter, setClassFilter] = useState("all");
    const [statusFilter, setStatusFilter] = useState("active");
    const [deleteModal, setDeleteModal] = useState({ isOpen: false, studentId: null });
    const [stats, setStats] = useState({ total: 0, active: 0, inactive: 0 });
    const [currentPage, setCurrentPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const pageSize = 25;

    // Debounce search input - wait 400ms after user stops typing
    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearch(search);
        }, 400);
        return () => clearTimeout(timer);
    }, [search]);

    // Reset to page 1 when filters change
    useEffect(() => {
        setCurrentPage(1);
    }, [debouncedSearch, classFilter, statusFilter]);

    // Fetch students when page or filters change
    useEffect(() => {
        fetchStudents();
    }, [debouncedSearch, classFilter, statusFilter, currentPage]);

    // Fetch class levels and stats once on mount
    useEffect(() => {
        fetchClassLevels();
        fetchStats();
    }, []);

    const fetchStudents = async () => {
        setLoading(true);
        try {
            const params = { page: currentPage, page_size: pageSize };
            if (debouncedSearch) params.search = debouncedSearch;
            if (classFilter !== "all") params.class_level = classFilter;
            if (statusFilter !== "all") params.is_active = statusFilter === "active";

            const response = await studentsAPI.list(params);
            const data = response.data;
            
            if (data.results) {
                setStudents(data.results);
                setTotalCount(data.count || data.results.length);
            } else {
                setStudents(Array.isArray(data) ? data : []);
                setTotalCount(Array.isArray(data) ? data.length : 0);
            }
        } catch (error) {
            console.error("Failed to fetch students:", error);
        } finally {
            setLoading(false);
        }
    };

    const fetchClassLevels = async () => {
        try {
            const response = await classLevelsAPI.list();
            setClassLevels(response.data.results || response.data || []);
        } catch (error) {
            console.error("Failed to fetch class levels:", error);
        }
    };

    const fetchStats = async () => {
        try {
            const response = await studentsAPI.stats();
            setStats(response.data);
        } catch (error) {
            console.error("Failed to fetch stats:", error);
        }
    };

    const handleDelete = async () => {
        try {
            await studentsAPI.delete(deleteModal.studentId);
            setStudents(students.filter((s) => s.id !== deleteModal.studentId));
            setDeleteModal({ isOpen: false, studentId: null });
            fetchStats();
        } catch (error) {
            console.error("Failed to delete student:", error);
        }
    };

    const handleExportCSV = async () => {
        try {
            const response = await studentsAPI.exportCSV();
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'students_export.csv');
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            console.error("Failed to export CSV:", error);
        }
    };

    const handleExportForCBT = async () => {
        try {
            const response = await studentsAPI.exportForCBT();

            if (response.headers['content-type'] === 'text/csv') {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'students_for_cbt.csv');
                document.body.appendChild(link);
                link.click();
                link.remove();
            } else {
                const data = response.data;
                const csvContent = [
                    ['admission_number', 'first_name', 'middle_name', 'last_name', 'class_level', 'password_plain'].join(','),
                    ...data.map(student => [
                        student.admission_number,
                        student.first_name,
                        student.middle_name || '',
                        student.last_name,
                        student.class_level || student.class_level_name,
                        student.password || student.password_plain
                    ].join(','))
                ].join('\n');

                const blob = new Blob([csvContent], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'students_for_cbt.csv');
                document.body.appendChild(link);
                link.click();
                link.remove();
            }

            alert(`✅ Exported students in CBT format!\n\nFormat: admission_number, first_name, middle_name, last_name, class_level, password_plain`);
        } catch (error) {
            console.error("Failed to export CBT credentials:", error);
            alert("❌ Failed to export credentials. Please try again.");
        }
    };

    const columns = [
        {
            key: "admission_number",
            label: "Admission No.",
            render: (value, row) => (
                <div className="flex items-center gap-2">
                    {/* Show passport thumbnail if available */}
                    {row.passport ? (
                        <img
                            src={row.passport}
                            alt={row.full_name || row.first_name}
                            className="w-8 h-8 rounded-full object-cover border border-gray-200"
                            onError={(e) => { e.target.style.display = 'none'; }}
                        />
                    ) : (
                        <span className="text-2xl">🎓</span>
                    )}
                    <button
                        onClick={() => navigate(`/students/${row.id}/edit`)}
                        className="text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                    >
                        {value}
                    </button>
                </div>
            ),
        },
        {
            key: "full_name",
            label: "Full Name",
            render: (value, row) => value || `${row.first_name} ${row.middle_name ? row.middle_name + ' ' : ''}${row.last_name}`,
        },
        {
            key: "class_level_name",
            label: "Class",
            render: (value, row) => (
                <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 rounded-full px-3 py-1 text-sm font-semibold">
                    {value || row.class_level_name || 'N/A'}
                </span>
            ),
        },
        {
            key: "gender",
            label: "Gender",
            render: (value) => value === 'M' ? '👨 Male' : '👩 Female',
        },
        {
            key: "date_of_birth",
            label: "Date of Birth",
            render: (value) => value ? new Date(value).toLocaleDateString() : 'N/A',
        },
        {
            key: "is_active",
            label: "Status",
            render: (value) => (
                <span className={`rounded-full px-3 py-1 text-sm font-semibold ${
                    value
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300'
                        : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300'
                }`}>
                    {value ? '✓ Active' : '✗ Inactive'}
                </span>
            ),
        },
        {
            key: "id",
            label: "Actions",
            render: (value, row) => (
                <div className="flex gap-2">
                    <Button size="sm" onClick={() => navigate(`/students/${value}/edit`)}>
                        Edit
                    </Button>
                    <Button
                        size="sm"
                        variant="danger"
                        onClick={() => setDeleteModal({ isOpen: true, studentId: value })}
                    >
                        Delete
                    </Button>
                </div>
            ),
        },
    ];

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Student Management</h1>
                    <p className="text-gray-600 dark:text-gray-400 mt-1">
                        {stats.total} students • {stats.active} active • {stats.inactive} inactive
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button variant="secondary" onClick={handleExportCSV}>
                        📥 Export CSV
                    </Button>
                    <Button variant="primary" onClick={handleExportForCBT} title="Export in format: admission_number, first_name, middle_name, last_name, class_level, password_plain">
                        🔐 Export for CBT
                    </Button>
                    <Button variant="secondary" onClick={() => navigate("/students/bulk-upload")}>
                        📤 Bulk Upload
                    </Button>
                    <Button onClick={() => navigate("/students/create")}>
                        Add Student +
                    </Button>
                </div>
            </div>

            {/* CBT Export Info */}
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 dark:text-blue-300 mb-2">📋 CBT Export Format</h3>
                <p className="text-sm text-blue-800 dark:text-blue-400">
                    The "Export for CBT" button exports students in this format:<br/>
                    <code className="bg-white dark:bg-gray-800 px-2 py-1 rounded text-xs">
                        admission_number, first_name, middle_name, last_name, class_level, password_plain
                    </code>
                </p>
                <p className="text-sm text-blue-800 dark:text-blue-400 mt-2">
                    This file can be directly uploaded to the CBT system for student import.
                </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
                <Input
                    placeholder="Search students..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="flex-1"
                />
                <select
                    value={classFilter}
                    onChange={(e) => setClassFilter(e.target.value)}
                    className="px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                >
                    <option value="all">All Classes</option>
                    {classLevels.map((cls) => (
                        <option key={cls.id} value={cls.id}>
                            {cls.name}
                        </option>
                    ))}
                </select>
                <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                >
                    <option value="all">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>

            <Table columns={columns} data={students} loading={loading} />

            {/* Pagination Controls */}
            {totalCount > pageSize && (
                <div className="flex items-center justify-between bg-white dark:bg-gray-800 rounded-xl p-4 shadow">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                        Showing {((currentPage - 1) * pageSize) + 1} - {Math.min(currentPage * pageSize, totalCount)} of {totalCount} students
                    </p>
                    <div className="flex gap-2">
                        <button
                            onClick={() => setCurrentPage(1)}
                            disabled={currentPage === 1}
                            className="px-3 py-2 rounded-lg text-sm font-medium bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                            First
                        </button>
                        <button
                            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                            disabled={currentPage === 1}
                            className="px-3 py-2 rounded-lg text-sm font-medium bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                            ← Prev
                        </button>
                        <span className="px-4 py-2 rounded-lg text-sm font-bold bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300">
                            Page {currentPage} of {Math.ceil(totalCount / pageSize)}
                        </span>
                        <button
                            onClick={() => setCurrentPage(prev => Math.min(Math.ceil(totalCount / pageSize), prev + 1))}
                            disabled={currentPage >= Math.ceil(totalCount / pageSize)}
                            className="px-3 py-2 rounded-lg text-sm font-medium bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                            Next →
                        </button>
                        <button
                            onClick={() => setCurrentPage(Math.ceil(totalCount / pageSize))}
                            disabled={currentPage >= Math.ceil(totalCount / pageSize)}
                            className="px-3 py-2 rounded-lg text-sm font-medium bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                            Last
                        </button>
                    </div>
                </div>
            )}

            <Modal
                isOpen={deleteModal.isOpen}
                title="Delete Student?"
                onClose={() => setDeleteModal({ isOpen: false, studentId: null })}
                actions={[
                    { label: "Cancel", onClick: () => setDeleteModal({ isOpen: false, studentId: null }) },
                    { label: "Delete", variant: "danger", onClick: handleDelete },
                ]}
            >
                <p className="text-gray-600 dark:text-gray-400">
                    Are you sure you want to delete this student? This action will set the student as inactive.
                </p>
            </Modal>
        </div>
    );
}